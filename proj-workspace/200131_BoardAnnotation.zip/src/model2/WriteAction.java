package model2;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WriteAction implements BoardAction {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		System.out.println( "WriteAction 호출" );
		
		String cpage = request.getParameter( "cpage" );
		
		request.setAttribute( "cpage", cpage );
	}

}
